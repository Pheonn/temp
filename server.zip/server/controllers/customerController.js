const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Customer = require("../models/customer");



const findCustomers = async (req, res) => {
    // Find the customer
    const customer = await Customer.find();
    // Respond with customer information
    res.json({ customer: customer })
};

const findCustomer = async (req, res) => {
    // Get id from the URL
    const customerId = req.params._id;
    // Find the customer by id
    const customer = await Customer.findById(customerId);
    // Respond with customer information
    res.json({ customer: customer})
};

const createCustomer = async (req, res) => {
    try {
        // Get the data from the request body
        const {
            first_Name,
            last_Name,
            email,
            password,
            mobile,
            Address,
            Membership,
            Status,
            Booking
        } = req.body;
        
        // Hash the password before storing it
        const hashedPassword = bcrypt.hashSync(password, 10);

        // Create a customer with the provided data
        const customer = await Customer.create({
            first_Name,
            last_Name,
            email,
            password: hashedPassword,
            mobile,
            Address,
            Membership,
            Status,
            Booking
        });
        
        // Respond with the newly created customer
        res.status(200).json({ customer: customer });
    } catch (error) {
        console.log(error)
        // Handle errors and respond with an error message
        res.status(500).json({ error: "An error occurred while creating the customer." });
    }
};

const updateCustomer = async (req, res) => {
    try {
        // Get the id from the URL
        const customerId = req.params._id;

        // Get customer information off req body
        const {
            _id,
            userName,
            first_Name,
            last_Name,
            email,
            mobile,
            Address,
            Membership,
            Status,
            Booking
        } = req.body;

        // Update the customer's information
        const updatedCustomer = await Customer.findByIdAndUpdate(
            customerId,
            {
                _id: _id,
                userName: userName,
                first_Name: first_Name,
                last_Name: last_Name,
                email: email,
                mobile: mobile,
                Address: Address,
                Membership: Membership,
                Status: Status,
                Booking: Booking
            },
            { new: true } // Return the updated document
        );

        if (!updatedCustomer) {
            return res.status(404).json({ error: "Customer not found." });
        }

        // Respond with the updated customer
        res.json({ customer: updatedCustomer });
    } catch (error) {
        // Handle errors and respond with an error message
        res.status(500).json({ error: "An error occurred while updating the customer." });
    }
};

const deleteCustomer = async (req, res) => {
    // Get id from the URL
    const customerId = req.params._id;
    // Delete the customer information
    await Customer.deleteOne({ _id: customerId });
    // Respond when deleted
    res.json({ sucess: "Customer information deleted" });
};


async function login(req, res) {
    // Get the email and password from req body
    const { email, password } = req.body;

    try {
        // Find the user with requested email
        const customer = await Customer.findOne({ email });
        if (!customer) return res.sendStatus(401);

        // Compare sent-in password with found user password hash
        const passwordMatch = await bcrypt.compare(password, customer.password);
        if (!passwordMatch) return res.sendStatus(401);

        // Create a JWT token
        // Set expiration to 30 days from now
        const exp = Date.now() + 1000 * 60 * 60 * 24;
        const token = jwt.sign({ sub: customer._id, exp }, process.env.SECRET);

        // Set the cookie
        res.cookie("Authorization", token, {
            expires: new Date(exp),
            httpOnly: true,
            sameSite: 'lax',
            secure: process.env.NODE_ENV === "production",

        })

        // Send back the token
        res.sendStatus(200);
    } catch (error) {
        // Handle any errors
        console.error(error);
        res.status(500).json({ error: "An error occurred while logging in." });
    }
}

function logout(req, res){
    try{ 
    res.clearCookie("Authorization");
    res.sendStatus(200);
    } catch(err) {
        console.log(err);
        res.sendStatus(400);
    }
}

function checkAuth(req, res){
    try{
        res.sendStatus(200)
    } catch(err) {
        return res.sendStatus(400);
    }

}


module.exports = {
    findCustomers,
    findCustomer,
    createCustomer,
    updateCustomer,
    deleteCustomer,
    login,
    logout,
    checkAuth
};
