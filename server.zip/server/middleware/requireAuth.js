const jwt = require('jsonwebtoken');
const Customer = require('../models/customer')

async function requireAuth(req, res, next) {
    try { 
        // Read token off cookies
        const token = req.cookies.Authorization;
        if (!token) return res.sendStatus(401);
        // Decode the token
        const decoded = jwt.verify(token, process.env.SECRET);

        // Check expiration
        if (Date.now() > decoded.exp) return res.sendStatus(401);

        // Find user using decoded sub
        const customer = await Customer.findById(decoded.sub)
        if (!customer) return res.sendStatus(401);

        // attach user to req
        req.customer = customer;

        // continue on
        next();
    } catch(err) {
        return res.sendStatus(401);
    }
}

module.exports = requireAuth;
