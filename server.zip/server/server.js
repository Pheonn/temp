//Load environmental variables
if (process.env.NODE_ENV != "production"){
    require("dotenv").config();
}

// Importing dependencies
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const connectToDb = require('./config/connectToDb');
const customerController = require("./controllers/customerController");
const requireAuth = require("./middleware/requireAuth");

// Creating an express app
const app = express();

// Configure express app
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // For parsing form data
app.use(cookieParser());
app.use(
    cors({
        origin: true,
        credentials: true
    })
);

// Connect to database
connectToDb();

// Routing
app.post('/customer', customerController.createCustomer);
app.post('/login', customerController.login);
app.get('/logout', customerController.logout);
app.get('/check-auth', requireAuth, customerController.checkAuth);

app.get("/customer", customerController.findCustomers);
app.get("/customer/:_id", customerController.findCustomer);
app.put("/customer/:_id", customerController.updateCustomer);
app.delete("/customer/:_id", customerController.deleteCustomer);

// Starting our server
app.listen(process.env.PORT, () => {
    console.log(`Server is running on port ${process.env.PORT}`);
});
