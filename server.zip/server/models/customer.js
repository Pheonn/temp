const mongoose = require("mongoose");

const custSchema = new mongoose.Schema({
    first_Name: {
        type: String,
        required: true
    },
    last_Name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        index: true
    },
    password: {
        type: String,
        required: true
    },
    mobile: {
        type: String,
        required: true
    },
    Address: {
        street: {
            type: String,
            required: true
        },
        suburb: {
            type: String,
            required: true
        },
        state: {
            type: String,
            required: true
        },
        postcode: {
            type: Number,
            required: true
        }
    },
    Membership: {
        type: {
            type: String,
            required: true
        },
        duration: {
            type: Number,
            required: true
        },
        start_date: {
            type: String,
            required: true
        },
        end_date: {
            type: String,
            required: true
        },
        price: {
            type: Number,
            required: true
        }
    },
    Status: {
        Staff: {
            role: {
                type: String,
                required: true
            },
            business_email: {
                type: String,
                required: true
            }
        },
        ban: {
            type: Boolean,
            required: true
        },
        appeal: {
            type: Boolean,
            required: true
        },
        duration: {
            type: Number,
            required: true
        }
    },
    Booking: {
        start_date: {
            type: String,
            required: true
        },
        end_date: {
            type: String,
            required: true
        },
        Payment: {
            method: {
                type: String,
                required: true
            },
            payment_date: {
                type: String,
                required: true
            },
            amount: {
                type: Number,
                required: true
            }
        },
        Car: {
            brand: {
                type: String,
                required: true
            },
            year: {
                type: Number,
                required: true
            },
            model: {
                type: String,
                required: true
            },
            seat: {
                type: Number,
                required: true
            },
            availability: {
                type: Boolean,
                required: true
            },
            Condition: {
                type_of_repair: {
                    type: String,
                    required: true
                },
                finished_date: {
                    type: String,
                    required: true
                },
                cost_of_repair: {
                    type: Number,
                    required: true
                }
            }
        }
    }
});

const Customer = mongoose.model("Customer", custSchema);

module.exports = Customer;
